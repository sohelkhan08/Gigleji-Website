const resError = require('./resError');

// handles express protected routes using async/await to ensure errors get logged
const asyncProtectedRoute =
  (route) =>
    (req, res, next = console.error) => {
      if (req.session.key) {
      // session found
        return Promise.resolve(route(req, res)).catch(next);
      } else {
      // session not found
        return resError(
          res,
          {
            message: 'session not found',
          },
          401
        );
      }
    };

module.exports = asyncProtectedRoute;
