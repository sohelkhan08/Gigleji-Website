const colors = require('colors');

// eslint-disable-next-line no-undef
module.exports = (data, error = false) =>
  error ? console.log(colors.red(data)) : console.log(colors.brightCyan(data));
