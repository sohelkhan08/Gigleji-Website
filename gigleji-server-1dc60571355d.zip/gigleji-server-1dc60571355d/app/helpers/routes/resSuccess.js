// reusable function to respond to requests with a success status in a consistent data format
module.exports = (res, result = null, status = 200, message = 'success') => {
  res.status(status).json({
    message,
    result,
  });
};
