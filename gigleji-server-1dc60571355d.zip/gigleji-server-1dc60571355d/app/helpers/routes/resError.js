// reusable function to respond to requests with an error status in a consistent data format
module.exports = (res, result = null, status = 400, message = 'error') => {
  res.status(status).json({
    message,
    result,
  });
};
