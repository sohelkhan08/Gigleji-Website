const generateToken = require('./generateToken');

const logToken = async () => {
  const token = await generateToken();
  console.log('Token: ', token);
};

logToken();
