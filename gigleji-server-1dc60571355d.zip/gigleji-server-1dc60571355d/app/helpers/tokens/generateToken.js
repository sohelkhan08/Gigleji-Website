const generateToken = () => {
  return new Promise((resolve) => {
    require('crypto').randomBytes(48, (err, buffer) => {
      const token = buffer.toString('hex');
      resolve(token);
    });
  });
};

const getToken = async () => await generateToken();

module.exports = getToken;
