const dropColumn = (knex, tableName, columnName) => {
  return knex.schema.hasColumn(tableName, columnName).then((hasColumn) => {
    if (hasColumn) {
      return knex.schema.alterTable(tableName, (table) => {
        table.dropColumn(columnName);
      });
    } else {
      return null;
    }
  });
};

module.exports = dropColumn;
