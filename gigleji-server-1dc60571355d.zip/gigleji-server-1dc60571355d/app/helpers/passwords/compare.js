const md5 = require('md5');

module.exports = (password, hash) => md5(password) === hash;
