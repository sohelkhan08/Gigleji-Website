const md5 = require('md5');

module.exports = (password) => md5(password);
