module.exports = mongoose => {
  var schema = mongoose.Schema(
    {
      userId: String,
      domain: String,
      primarySkills: String,
      published: Boolean,
      lastLogin: String,
      address: String,
      pancard: String,
      aadharNumber: Number,
      lastLogin:Date,
      firstName:String,
      lastName:String,
      email:String,
      yourLocation:String,
      preferredLocation:String,
      phoneNumber:Number,
      whatsappNumber:Number,
      primarySkills:String,
      birthDate:Date,
      address:String,
      passport:String,
      gst:String,
      secondaruSkills:String,
      anyotherSkill:String,
      organization:String,
      projectName:String,
      projectFrom:Date,
      projectTo:Date,
      partTime:String,
      fullTime:String,
      onSite:String,
      OffSite:String,
      Both:String,
      needBased:String,
      zeroToSevenDays:String,
      eightFifteenDays:String,
      sixteenToThirtyDays:String,
      thirtyDays:String,
      qualifications:String,
      courseTime:Number,
      collegeUniversity:String,
      specialization:String,
      joiningDate:Date,
      passedDate:Date,
      employer:String,
      designation:String,
      experienceForm:Date,
      experienceTo:Date,
      description:String,























      



      





      








      


      


    },
    { timestamps: true }
  );

  schema.method("toJSON", function () {
    const { __v, _id, ...object } = this.toObject();
    object.id = _id;
    return object;
  });

  const userInfo = mongoose.model("userinfo", schema);
  return userInfo;
};
