module.exports = mongoose => {
  var schema = mongoose.Schema(
    {
      userId: String,
      published: Boolean,
      lastLogin: String,
      imageUrl:String,
      address:String,
      logoUrl:String,

    },
    { timestamps: true }
  );

  schema.method("toJSON", function () {
    const { __v, _id, ...object } = this.toObject();
    object.id = _id;
    return object;
  });

  const UserDetail = mongoose.model("userdetails", schema);
  return UserDetail;
};
