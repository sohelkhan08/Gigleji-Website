
const db = require("../models");
const UserDetail = db.userDetails;
const md5 = require("md5")

// Create and Save a new user
exports.create = (req, res) => {
    // Validate request
    if (!req.body.primarySkills) {
        res.status(400).send({ message: "Content can not be empty!" });
        return;
    }
    console.log(req.body);
    // Create a user
    const userdetail = new UserDetail({
        userId: req.body.userId,
        primarySkills: req.body.primarySkills,
        lastLogin: req.body.lastLogin,
        imageUrl:req.body.imageUrl,
        address:req.body.address,
        photoUrl:req.body.photoUrl,


    });

    // Save user in the database
    userdetail
        .save(userdetail)
        .then(data => {
            res.send(data);
        })
        .catch(err => {
            res.status(500).send({
                message:
                    err.message || "Some error occurred while creating the user."
            });
        });
};

// Retrieve all users from the database.

//login user




// Find a single Tutorial with an id


// Update a user by the id in the request


// Delete a user with the specified id in the request


// Delete all users from the database.


// Find all published users

