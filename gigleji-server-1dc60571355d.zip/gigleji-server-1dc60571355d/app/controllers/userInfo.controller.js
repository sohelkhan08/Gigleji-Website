
const db = require("../models");
const userInfo = db.userInfo;
const md5 = require("md5")

// Create and Save a new user
exports.create = (req, res) => {
    // Validate request
    if (!req.body.userId) {
        res.status(400).send({ message: "Content can not be empty!" });
        return;
    }
    console.log(req.body);
    // Create a user
    const userinfo = new userInfo({
        userId: req.body.userId,
        domain: req.body.domain,
        firstName:req.body.firstName,
        lastName:req.body.lastName,
        email:req.body.email,
        yourLocation:req.body.yourLocation,
        preferredLocation:req.body.preferredLocation,
        phoneNumber:req.body.phoneNumber,
        whatsappNumber:req.body.whatsappNumber,
        primarySkills: req.body.primarySkills,
        birthDate:req.body.birthDate,
        lastLogin: req.body.lastLogin,
        address: req.body.address,
        pancard: req.body.pancard,
        aadharNumber: req.body.aadharNumber,
        passport: req.body.passport,
        gst:req.body.gst,
        secondaruSkills:req.body.secondaruSkills,
        anyotherSkill:req.body.anyotherSkill,
        organization:req.body.organization,
        projectName:req.body.projectName,
        projectFrom:req.body.projectFrom,
        projectTo:req.body.projectTo,
        partTime:req.body.partTime,
        fullTime:req.body.fullTime,
        onSite:req.body.onSite,
        OffSite:req.body.OffSite,
        Both:req.body.Both,
        needBased:req.body.needBased,
        zeroToSevenDays:req.body.zerotosevenDays,
        eightFifteenDays:req.body.eightFifteenDays,
        sixteenToThirtyDays:req.body. sixteenToThirtyDays,
        thirtyDays:req.body.thirtyDays,
        qualifications:req.body.qualifications,
        courseTime:req.body.courseTime,
        collegeUniversity:req.body.collegeUniversity,
        specialization:req.body.specialization,
        joiningDate:req.body.joiningDate,
        passedDate:req.body.passedDate,
        employer:req.body.employer,
        designation:req.body.designation,
        experienceForm:req.body.experienceForm,
        experienceTo:req.body.experienceTo,
        description:req.body.description,






    });

    // Save user in the database
    userinfo
        .save(userinfo)
        .then(data => {
            if (data) {
                res.send({
                    message: "User Info updated",
                    data: data
                });
            } else {
                res.send({
                    message: "User Info is not updated",
                    // data: data
                });
            }
        })
        .catch(err => {
            res.status(500).send({
                message:
                    err.message || "Some error occurred while creating the user."
            });
        });
};

// Retrieve all users from the database.

//login user




// Find a single Tutorial with an id


// Update a user by the id in the request


// Delete a user with the specified id in the request


// Delete all users from the database.


// Find all published users

