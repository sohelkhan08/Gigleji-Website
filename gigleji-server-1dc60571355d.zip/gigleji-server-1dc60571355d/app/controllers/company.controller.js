
const db = require("../models");
const Company = db.companys;
const md5 = require("md5");
const { companys } = require("../models");



// Create and Save a new user
exports.create = (req, res) => {
    // Validate request
    if (!req.body.companyName) {
        res.status(400).send({ message: "Content can not be empty!" });
        return;
    }
    console.log(req.body);
    // Create a user
    const companyDetail = new Company({
        companyName:req.body.companyName,
        lastLogin: req.body.lastLogin,
        address:req.body.address,
        logoUrl:req.body.logoUrl,
        gstNo:req.body.gstNo,
        emailAddress:req.body.emailAddress,
        password:md5(req.body.password),
        registrationNo:req.body.registrationNo
    });

    // Save user in the database
    companyDetail
        .save(companyDetail)
        .then(data => {
            res.send(data);
        })
        .catch(err => {
            res.status(500).send({
                message:
                    err.message || "Some error occurred while creating the user."
            });
        });
};
exports.loginCompany = (req, res) => {

    if (!req.body.emailAddress || !req.body.password) {
      res.status(400).send({ message: "Content cannot be empty!" });
      return;
    }
  
    companys.findOne({ emailAddress: req.body.emailAddress })
      .then(data => {
        console.log(data);
  
        if (data && data.password === md5(req.body.password)) {
          res.send({
            message: "login success",
            data: data
          });
        } else if (data && data.password != md5(req.body.password)) {
          res.send({
            message: "Wrong password entered",
            // data: data
          });
        } else {
          res.send({
            message: "User not found with " + req.body.emailAddress,
          });
        }
      })
      .catch(err => {
        res.status(500).send({
          message:
            err.message || "Some error occurred while retrieving users."
        });
      });
  };

// Retrieve all users from the database.

//login user




// Find a single Tutorial with an id


// Update a user by the id in the request


// Delete a user with the specified id in the request


// Delete all users from the database.


// Find all published users

