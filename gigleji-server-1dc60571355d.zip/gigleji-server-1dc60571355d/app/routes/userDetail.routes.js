const express = require('express');
const router = express.Router();
const userDetails = require("../controllers/userDetail.controller.js");

// Create a new Tutorial
router.post("/", userDetails.create);


 

module.exports = router;
