const express = require('express');
const router = express.Router();
const userInfo = require("../controllers/userInfo.controller.js");

// Create a new Tutorial
router.post("/create", userInfo.create);




module.exports = router;
