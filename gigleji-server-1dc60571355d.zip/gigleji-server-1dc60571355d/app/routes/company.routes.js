const express = require('express');
const router = express.Router();
const  companys = require("../controllers/company.controller.js");

// Create a new Tutorial
router.post("/", companys.create);
router.post("/loginCompany", companys.loginCompany);

//Get one company
// router.get("/:id", companys.findOne);


module.exports = router;