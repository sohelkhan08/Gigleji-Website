const express = require('express');
const router = express.Router();
const logins = require("../controllers/login.controller.js");

// Create a new Tutorial
router.post("/", logins.create);

// Retrieve all login
router.get("/", logins.findAll);

// Retrieve all published login
router.get("/published", logins.findAllPublished);

// Retrieve a single Tutorial with id
router.get("/:id", logins.findOne);

// Update a Tutorial with id
router.put("/:id", logins.update);

// Delete a Tutorial with id
router.delete("/:id", logins.delete);

// Create a new Tutorial
router.delete("/", logins.deleteAll);

module.exports = router;
