# Change Log

## [1.0.0] 2022-01-12

### Original Release

- Added MUI as base framework
