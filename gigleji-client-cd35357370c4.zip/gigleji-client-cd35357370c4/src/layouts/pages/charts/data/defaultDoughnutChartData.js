/**
=========================================================
* Otis Admin PRO - v2.0.0
=========================================================

* Product Page: https://material-ui.com/store/items/otis-admin-pro-material-dashboard-react/
* Copyright 2022 Creative Tim (https://www.creative-tim.com)

Coded by www.creative-tim.com

 =========================================================

* The above copyright notice and this permission notice shall be included in all copies or substantial portions of the Software.
*/

export default {
  labels: ["Creative Tim", "Github", "Bootsnipp", "Dev.to", "Codeinwp"],
  datasets: {
    label: "Projects",
    backgroundColors: ["info", "dark", "error", "secondary", "primary"],
    data: [15, 20, 12, 60, 20],
  },
};
